#!/usr/bin/perl
open( $l, "<$ARGV[0]" ) || die "Error : $!";
my @lines = <$l>;
close( $l );

foreach my $line ( @lines ) {
  next if ( $line =~ /^\s*$/ );
  next if ( $line =~ /^\s*#/ );
  
  my ($dec, $temps) = split( /\s+/, $line );
  my $tpd = $temps/$dec;
  print "$dec\t$tpd\n";
}
